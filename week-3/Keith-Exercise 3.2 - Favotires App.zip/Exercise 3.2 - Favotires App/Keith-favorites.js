/*
=================================================
;  Title: favorites.js
;  Author: Alexander Keith
;  Date: 4/2/2023
;  Description: favorites.js file for assignment Exercise 3.2 - Favorites App
;================================================
*/

// alerts favorite team
function favoriteTeam() {
    alert("Alabama Crimson Tide")
}

// alerts favorite book
function favoriteBook() {
    alert("The Hobbit")
}

// alerts favorite author
function favoriteAuthor() {
    alert("JK Rowling")
}

// alerts favorite programming language
function favoriteLanguage() {
    alert("JavaScript")
}